// CSC 134
// M1T1
// Catherine Lucas
//1/19/19
#include <iostream>

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    cout << "My name is Catherine Lucas" << endl;
    cout << "This is my last year at FTCC" << endl;
    cout << "I have previously taken Java and Python programming" << endl;

    return 0;
}
